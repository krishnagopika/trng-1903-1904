# Lecture Plan

1. Scripting
2. Static Code analysis

---


### Conditionals


```bash
if [ condition ]; then
    #statements
elif [ condition ]; then

   #statements
else

fi
```


```bash
case value in

     match) ##statements
     ;;


esac 
```

#### Loops

#### functions


